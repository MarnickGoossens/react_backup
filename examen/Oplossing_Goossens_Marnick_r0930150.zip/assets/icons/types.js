export const types = [
    { image: require('../assets/icons/art.png'), icon: "art" }, 
    { image: require('../assets/icons/food.png'), icon: "food" }, 
    { image: require('../assets/icons/health.png'), icon: "health" }, 
    { image: require('../assets/icons/media.png'), icon: "media" }, 
    { image: require('../assets/icons/science.png'), icon: "science" }, 
    { image: require('../assets/icons/sport.png'), icon: "sport" }, 
    { image: require('../assets/icons/travel.png'), icon: "travel" }
];