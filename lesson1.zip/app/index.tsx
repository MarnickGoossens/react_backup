import { Text, View, StyleSheet } from 'react-native';
import Buttons from "./components/Buttons"
import FlexStyles from "./components/FlexStyles"
import UserInput from "./components/UserInput"
import ScrollStudents from "./components/ScrollStudents"
import Images from "./components/Images"

export default function Index() {
  return (
    <Images />
    // <View style={styles.container}>
    //   <Text style={styles.text}>Home screen</Text>
    // </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#555555',
    alignItems: 'center',
    justifyContent: 'center',
  },
  text:
  {
    color: '#fff',
  },
});
