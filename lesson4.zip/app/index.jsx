import { View, StyleSheet } from 'react-native';
import { ApolloClient, InMemoryCache, ApolloProvider } from '@apollo/client';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from "@expo/vector-icons";

import configData from "@/gql/config.json";

const client = new ApolloClient({
  uri: configData.qlendpoint,
  headers: {
    'x-hasura-admin-secret': configData.qlkey
  },
  cache: new InMemoryCache()
});

import ListContinents from '@/components/ListContinents';

import HomeScreen from '@/components/HomeScreen';
import CountryScreen from '@/components/CountryScreen';
import ContinentScreen from '@/components/ContinentScreen';
import SearchScreen from '@/components/SearchScreen';

const Tab = createBottomTabNavigator();
export default function Index() {
  return (
    <ApolloProvider client={client}>
      {/* <View style={styles.container}>
        <ListContinents />
      </View> */}
      
      <Tab.Navigator
          screenOptions={ ({ route }) => ({
            tabBarIcon: ({ focused, color, size }) => {
              let iconName;

              switch (route.name) {
                case "Home":
                  iconName = focused ? 'home-sharp' : 'home-outline';
                  break;
                case "Countries":
                  iconName = focused ? 'flag-sharp' : 'flag-outline';
                  break;
                case "Continents":
                  iconName = focused ? 'earth' : 'earth-outline';
                  break;
                case "Search":
                  iconName = focused ? 'search-circle' : 'search-circle-outline';
                  break;
              }

              return <Ionicons name={iconName} size={size} color={color} />;
            },
            tabBarActiveTintColor: 'tomato',
            tabBarInactiveTintColor: 'gray',
          })}
        >
        <Tab.Screen name="Home" component={HomeScreen} />
        <Tab.Screen name="Countries" component={CountryScreen} />
        <Tab.Screen name="Continents" component={ContinentScreen} />
        <Tab.Screen name="Search" component={SearchScreen} />
      </Tab.Navigator>
       
    </ApolloProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    margin: 20
  }
});