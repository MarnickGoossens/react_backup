import { SectionList } from 'react-native';

import { useQuery } from "@apollo/client";
import { GET_CONTINENTS_COUNTRIES } from "../gql/queries";

import Fetching from './FetchingMessage';
import Error from './ErrorMessage';
import Separator from './Seperator';

import CountryItem from './CountryItem';
import ContinentHeader from './ContinentHeader';

export default function ContinentScreen() {
  const { data, loading, error } = useQuery(GET_CONTINENTS_COUNTRIES);

  if (loading) return <Fetching />
  if (error) return <Error error={error} />

  // Transformeer de gegevens naar het juiste formaat voor SectionList
  const sections = data.continents.map(continent => ({
    title: continent.name,
    data: continent.countries.map(country => ({
      code: country.code,
      name: country.name,
      capital: country.capital,
      emoji: country.emoji,
  })),
}));
  return (
    <SectionList
      sections={sections}
      keyExtractor={(item, index) => item + index}
      renderItem={({ item }) => <CountryItem country={item} />}
      ItemSeparatorComponent={Separator}
      renderSectionHeader={({ section }) => <ContinentHeader continent={section} /> }
    />
  );
}
