import { FlatList } from 'react-native';

import { useQuery } from "@apollo/client";
import { GET_COUNTRIES } from "../gql/queries";

import Fetching from './FetchingMessage';
import Error from './ErrorMessage';
import Separator from './Seperator';

import CountryItem from './CountryItem';

export default function CountryScreen() {
  const { data, loading, error } = useQuery(GET_COUNTRIES);
  
  if (loading) return <Fetching />
  if (error) return <Error error={error} />

  return (
    <FlatList
      data={data.countries}
      renderItem={({ item }) => <CountryItem country={item} />}
      keyExtractor={(item, index) => index}
      ItemSeparatorComponent={Separator}
    />
  );
}