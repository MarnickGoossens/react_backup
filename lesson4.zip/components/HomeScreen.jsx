import { FlatList } from 'react-native'

import { useQuery } from "@apollo/client";
import { GET_CONTINENTS } from "../gql/queries";

import Fetching from './FetchingMessage';
import Error from './ErrorMessage';
import Separator from './Seperator';

import ContinentItem from './ContinentItem';

export default function HomeScreen() {
  const { data, loading, error } = useQuery(GET_CONTINENTS);

  if (loading) return <Fetching />
  if (error) return <Error error={error} />

  return (
    <FlatList
      data={data.continents}
      renderItem={({ item }) => <ContinentItem continent={item} />}
      keyExtractor={(item, index) => index}
      ItemSeparatorComponent={Separator}
    />
  );
}