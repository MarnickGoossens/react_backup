import { Text, FlatList } from 'react-native';
import { useQuery } from '@apollo/client';
import { GET_CONTINENTS } from '@/gql/queries';

export default function ListContinents() {
  const { data, loading, error } = useQuery(GET_CONTINENTS);

  if (loading) return <Text>Loading...</Text>
  if (error) return <Text>Error...</Text>

  return (
    <FlatList
      data={data.continents}
      renderItem={({ item }) => <Text>{item.name}</Text>}
      keyExtractor={(item, index) => index}
    />
  );
}